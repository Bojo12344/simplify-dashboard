// Placeholder content for postcss.config.js
